# Policyholder Demonstration
from Product_Manangement import ProductManager
from Payments_Management import PaymentManager
from Payments_Management import Payment
from Policy_Management import PolicyManager


policy_manager = PolicyManager()
product_manager = ProductManager()
payment_manager = PaymentManager()
payments = Payment()

# Register two sample policy holders
policyholder1 = PolicyManager().register_new_ph("John Doe", "john@example.com")
policyholder2 = PolicyManager().register_new_ph("Alice Stuart", "alice@example.com")


# Create two sample policy products
product1 = ProductManager.create_policy_product("Life Insurance", 100)
product2 = ProductManager.create_policy_product("Health Insurance", 50)

# Make two sample payments
pay1 = (policyholder1, product1)
pay1 = (policyholder2, product2)


