# Policyholder management
# Create separate classes for policyholders.
class Policyholder:
    def __init__(self, name, email, policy_number, status):
        self.name = name
        self.email = email
        self.policy_number = policy_number
        self.status = status
        self.policies = []

class PolicyManager:
    def register_new_ph(self, name, email):
        return Policyholder(name, email)

    def suspend_ph(self, policyholder):
        policyholder.status = "Suspended!"  # Makes a policyholder inactive
    
    def reactivate_ph(self, policyholder):
        policyholder.status = "Active!"   # Restores suspended policyholder back to active.
    
# Displaying account details of Policy holders
    def display(self):
        print(f"Name: {self.name}")
        print(f"Email: {self.email}")
        print(f"Policy Number: {self.policy_number}")
        print(f"Policy holder Status: {self.status}")
        print()