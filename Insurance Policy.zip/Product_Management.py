# Product Management
# Create separate class for products

class Product:
    def __init__(self, policy_name, price, tenure):
        self.policy_name = policy_name
        self.price = price
        self.tenure = tenure



class ProductManager:
    def create_product(self, policy_name):
        return Product(policy_name)
    

    # Creating a new product
    def create_policy_product(self):
        print(f"New policy product {self.policy_name} has been successfully created.")

    def update_product(self, policy_name, price, tenure):
        self.policy_name = policy_name
        self.price = price
        self.tenure = tenure
        print(f"{self.policy_name} has been successfully updated.")

    def remove_product(self):
        print(f"{self.policy_name} has been successfully suspended.")
        print(" ")          # Remove product logic here
        pass
