# Payments Management
# Create separate class for payments

from datetime import datetime
class Payment:
    def init(self, policyholder, product, payment_date, payment_status):
        self.policyholder = policyholder
        self.product = product
        self.payment_date = payment_date
        self.payment_status = payment_status



class PaymentManager:
    def process_payment(self, policyholder, product):
        payment = Payment(policyholder, product, datetime.now())
        policyholder.policies.append(payment)
        return payment

    def check_payment_status(self):
        if self.payment_status == "Defaulting":
            print(f"{self.policyholder.name} is defaulting to the tune of ${self.amount} for {self.product.name} as at {datetime.now()}")
        else:
            if self.payment_status == "Paid":
                print(f"{self.policyholder.name} has paid ${self.amount} for {self.product.name} as at {datetime.now()}")

    def send_reminder(self):
        if self.payment_status == "Defaulting":
            print(f"Reminder: {self.policyholder.name} must pay ${self.amount} for {self.product.name} by {self.date}")
        else:
            print(f"No reminder needed for {self.policyholder.name}") # Send reminder logic here
        pass

    def apply_penalty(self, policyholder):
        if self.payment_status == "Defaulting":
            penalty = self.amount * 0.01
            self.amount += penalty
            print(f"Penalty: {self.policyholder.name} is charged ${penalty} for {self.product.name} due to late payment.")
        else:
            print(f"No penalty needed for {self.policyholder.name}")
        pass